'''
Pregunta #1
Nombre: Victor Coto Solano
ID: 305440064
'''

def f_formula(n):
    return 1/2 * (7**n) + 1/2 * ((-5)**n)
    
